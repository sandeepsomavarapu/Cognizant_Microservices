package com.cognizant.springcore;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App {
	public static void main(String[] args) {
		Resource resource = new ClassPathResource("springconfig.xml");

		BeanFactory factory = new XmlBeanFactory(resource);

		Employee employee = (Employee) factory.getBean("emp");
		Employee employee1 = (Employee) factory.getBean("emp1");

		System.out.println(employee);
		System.out.println(employee1);
	}
}
